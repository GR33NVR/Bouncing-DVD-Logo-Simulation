Bouncing DVD Logo Simulation
--------------------------------------------------------------------------------------------------------------------------------------------
Created By. GR33NVR
--------------------------------------------------------------------------------------------------------------------------------------------
This is a simulation of the classic bouncing DVD Logo.
--------------------------------------------------------------------------------------------------------------------------------------------
Warning: DO NOT DELETE THE "dvd_logo.png" OR "DVDLOGOGREEN.ico" AS THIS WILL CAUSE PROBLEMS IN THE CODE AND WILL MAKE THE DVD LOGO AND THE APPLICATION ICON NOT LOAD.
--------------------------------------------------------------------------------------------------------------------------------------------
Controls:
To start click the button or press the Enter Key.

Backspace = pauses the simulation.

Esc = quits the application

F = toggles mouse visibility
--------------------------------------------------------------------------------------------------------------------------------------------Note: If there are any bugs you come across please contact me, my discord is gr33nvr.